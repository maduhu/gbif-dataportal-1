How to install
---------------

- Download the repository:

		$ git clone https://github.com/Vizzuality/Data.GBIF

- Install bundler gem and install all project's gems:

    $ cd Data.GBIF


    $ gem install bundler && bundle install

- Run the server

		$ rake run

After some secons the site will be generated and visible on http://localhost:3000.
